// =========================================================
// LOJANOVA — marca.js
// Carga un emprendedor (marca) por ?id=... y todos sus productos
// =========================================================

const navbar = document.getElementById("navbar");
window.addEventListener("scroll", () => navbar.classList.toggle("scrolled", window.scrollY > 40));
document.getElementById("navToggle")?.addEventListener("click", () => document.getElementById("navLinks").classList.toggle("open"));

function escapeHtml(str){
  return (str || "").replace(/[&<>"']/g, m => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[m]));
}
function cortar(str, n){ if(!str) return ""; return str.length > n ? str.slice(0,n).trim() + "…" : str; }
function lnTexto(es, en){
  const lang = localStorage.getItem("ln_lang") || "es";
  return (lang === "en" && en) ? en : es;
}

async function cargarMarca(){
  const id = new URLSearchParams(location.search).get("id");
  const header = document.getElementById("marcaHeader");
  const notFound = document.getElementById("marcaNotFound");
  if (!id){ header.style.display = "none"; notFound.style.display = "block"; return; }

  const { data: e, error } = await db
    .from("emprendedores")
    .select("*, cantones(nombre)")
    .eq("id", id)
    .eq("activo", true)
    .single();

  if (error || !e){ header.style.display = "none"; notFound.style.display = "block"; return; }

  header.style.display = "none";
  document.getElementById("marcaDetalle").style.display = "block";

  document.title = `${e.emprendimiento} — Lojanova`;
  document.getElementById("pageTitle").textContent = `${e.emprendimiento} — Lojanova`;
  document.getElementById("metaDescription").content = cortar(e.historia || `Marca lojana de ${e.cantones?.nombre || "Loja"}.`, 155);
  document.getElementById("ogTitle").content = `${e.emprendimiento} — Lojanova`;
  document.getElementById("ogDescription").content = cortar(e.historia || "", 155);

  document.getElementById("marcaFoto").src = urlImagen(e.foto_url, "producer");
  document.getElementById("marcaFoto").alt = e.emprendimiento;
  document.getElementById("marcaCanton").textContent = e.cantones?.nombre || "Loja";
  document.getElementById("marcaNombreEmprendimiento").textContent = e.emprendimiento;
  document.getElementById("marcaNombreDueno").textContent = e.nombre;
  document.getElementById("marcaExtra").textContent = e.anios_experiencia ? `${e.anios_experiencia} años de experiencia` : "";
  document.getElementById("marcaHistoria").textContent = e.historia || "";

  const contactos = document.getElementById("marcaContactos");
  const items = [];
  if (e.telefono) items.push(`<a href="tel:${e.telefono}" class="tag"><i data-lucide="phone" class="icon"></i> ${escapeHtml(e.telefono)}</a>`);
  if (e.whatsapp){
    const num = e.whatsapp.replace(/\D/g,"");
    items.push(`<a href="https://wa.me/${num}" target="_blank" rel="noopener" class="tag" data-track="contactar_whatsapp_marca"><i data-lucide="message-circle" class="icon"></i> WhatsApp</a>`);
  }
  if (e.correo) items.push(`<a href="mailto:${e.correo}" class="tag"><i data-lucide="mail" class="icon"></i> ${escapeHtml(e.correo)}</a>`);
  if (e.instagram) items.push(`<a href="${e.instagram}" target="_blank" rel="noopener" class="tag"><i data-lucide="instagram" class="icon"></i> Instagram</a>`);
  if (e.facebook) items.push(`<a href="${e.facebook}" target="_blank" rel="noopener" class="tag"><i data-lucide="facebook" class="icon"></i> Facebook</a>`);
  contactos.innerHTML = items.join("");

  await cargarProductosDeMarca(id);
  if (window.lucide) lucide.createIcons();
}

async function cargarProductosDeMarca(emprendedorId){
  const grid = document.getElementById("marcaProductos");
  const { data, error } = await db
    .from("productos")
    .select("*, categorias(nombre, nombre_en), cantones(nombre)")
    .eq("emprendedor_id", emprendedorId)
    .eq("activo", true)
    .order("created_at", { ascending: false });

  if (error || !data || data.length === 0){
    grid.innerHTML = `<div class="empty-state">Esta marca aún no tiene productos publicados.</div>`;
    return;
  }

  grid.innerHTML = data.map(p => `
    <article class="card-producto reveal">
      <div class="thumb">
        <img src="${escapeHtml(urlImagen(p.imagen_principal_url, "product"))}" alt="${escapeHtml(p.nombre)}" loading="lazy">
        ${p.es_exportacion ? '<span class="badge">Exportación</span>' : (p.es_artesanal ? '<span class="badge">Artesanal</span>' : '')}
      </div>
      <div class="card-body">
        <div class="card-meta"><span>${escapeHtml(lnTexto(p.categorias?.nombre || '', p.categorias?.nombre_en))}</span><span>${escapeHtml(p.cantones?.nombre || '')}</span></div>
        <h3>${escapeHtml(lnTexto(p.nombre, p.nombre_en))}</h3>
        <p>${escapeHtml(cortar(lnTexto(p.descripcion_corta, p.descripcion_corta_en), 100))}</p>
        <a href="producto.html?slug=${encodeURIComponent(p.slug)}" class="btn btn-ghost btn-sm">Ver detalles</a>
      </div>
    </article>
  `).join("");
}

cargarMarca();
