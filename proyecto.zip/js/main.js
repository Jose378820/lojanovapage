// =========================================================
// LOJANOVA — main.js
// Interacciones de la landing + carga de datos desde Supabase
// =========================================================

/* ---------- Navbar ---------- */
const navbar = document.getElementById("navbar");
const navToggle = document.getElementById("navToggle");
const navLinks = document.getElementById("navLinks");

function setNavbarState() {
  navbar.classList.toggle("scrolled", window.scrollY > 40);
}
setNavbarState();
window.addEventListener("scroll", setNavbarState, { passive: true });
navToggle?.addEventListener("click", () => navLinks.classList.toggle("open"));
navLinks?.querySelectorAll("a").forEach(a => a.addEventListener("click", () => navLinks.classList.remove("open")));

/* ---------- Hero slider + movimiento ---------- */
const heroSlides = [...document.querySelectorAll(".hero-bg")];
const heroDots = [...document.querySelectorAll(".hero-dots span")];
let activeHeroSlide = 0;
if (heroSlides.length > 1) {
  setInterval(() => {
    heroSlides[activeHeroSlide].classList.remove("is-active");
    heroDots[activeHeroSlide]?.classList.remove("is-active");
    activeHeroSlide = (activeHeroSlide + 1) % heroSlides.length;
    heroSlides[activeHeroSlide].classList.add("is-active");
    heroDots[activeHeroSlide]?.classList.add("is-active");
  }, 5200);
}

/* ---------- Parallax liviano ---------- */
let ticking = false;
function updateParallax() {
  const viewportCenter = window.innerHeight / 2;
  document.querySelectorAll("[data-parallax-section]").forEach(section => {
    const rect = section.getBoundingClientRect();
    if (rect.bottom < 0 || rect.top > window.innerHeight) return;
    const offset = (rect.top + rect.height / 2 - viewportCenter) * -0.08;
    section.style.setProperty("--parallax-y", `${Math.max(-36, Math.min(36, offset))}px`);
  });
  ticking = false;
}
function requestParallax() {
  if (ticking) return;
  ticking = true;
  requestAnimationFrame(updateParallax);
}
window.addEventListener("scroll", requestParallax, { passive: true });
window.addEventListener("resize", requestParallax);
requestParallax();

/* ---------- Scroll reveal ---------- */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add("visible"); revealObserver.unobserve(e.target); } });
}, { threshold: 0.15 });
function observeReveals(){
  document.querySelectorAll(".reveal:not(.visible)").forEach((el, index) => {
    el.style.setProperty("--stagger-delay", `${Math.min(index * 70, 420)}ms`);
    revealObserver.observe(el);
  });
}
observeReveals();

/* ---------- Cards 3D sutiles ---------- */
function enhanceProductTilt(){
  document.querySelectorAll(".card-producto:not([data-tilt-ready])").forEach(card => {
    card.dataset.tiltReady = "true";
    card.addEventListener("pointermove", event => {
      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      const rect = card.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - .5;
      const y = (event.clientY - rect.top) / rect.height - .5;
      card.classList.add("is-tilting");
      card.style.transform = `perspective(900px) rotateX(${(-y * 5).toFixed(2)}deg) rotateY(${(x * 5).toFixed(2)}deg) translateY(-6px)`;
    });
    card.addEventListener("pointerleave", () => {
      card.classList.remove("is-tilting");
      card.style.transform = "";
    });
  });
}

/* ---------- Helpers ---------- */
function escapeHtml(str){
  return (str || "").replace(/[&<>"']/g, m => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[m]));
}
function cortar(str, n){ if(!str) return ""; return str.length > n ? str.slice(0,n).trim() + "…" : str; }
function lnTexto(es, en){
  const lang = localStorage.getItem("ln_lang") || "es";
  return (lang === "en" && en) ? en : es;
}

/* ---------- Estado global de filtros ---------- */
let PRODUCTOS = [];
let CATEGORIAS = [];
let CANTONES = [];

/* ---------- Cargar categorías ---------- */
async function cargarCategorias(){
  const { data, error } = await db.from("categorias").select("*").order("orden");
  const grid = document.getElementById("catGrid");
  const selectCat = document.getElementById("fCategoria");
  if (error || !data || data.length === 0){
    grid.innerHTML = `<div class="empty-state">Aún no hay categorías cargadas. Ingresa al panel de administración para crear la primera.</div>`;
    return;
  }
  CATEGORIAS = data;
  grid.innerHTML = data.map(c => `
    <div class="cat-card reveal" data-cat="${c.id}">
      <img src="${escapeHtml(urlImagenCategoria(c.imagen_url, c.nombre))}" alt="${escapeHtml(lnTexto(c.nombre, c.nombre_en))}" loading="lazy">
      <div class="cat-card-label">
        <h3>${escapeHtml(lnTexto(c.nombre, c.nombre_en))}</h3>
        <span>Ver productos</span>
      </div>
    </div>
  `).join("");
  selectCat.innerHTML = `<option value="">Categoría</option>` + data.map(c => `<option value="${c.id}">${escapeHtml(c.nombre)}</option>`).join("");
  grid.querySelectorAll(".cat-card").forEach(card => {
    card.addEventListener("click", () => {
      selectCat.value = card.dataset.cat;
      document.getElementById("catalogo").scrollIntoView({ behavior: "smooth" });
      renderProductos();
    });
  });
  observeReveals();
}

/* ---------- Cargar cantones ---------- */
async function cargarCantones(){
  const { data, error } = await db.from("cantones").select("*").order("orden");
  const selectCanton = document.getElementById("fCanton");
  const pillList = document.getElementById("cantonList");
  if (error || !data) return;
  CANTONES = data;
  selectCanton.innerHTML = `<option value="">Cantón</option>` + data.map(c => `<option value="${c.id}">${escapeHtml(c.nombre)}</option>`).join("");
  pillList.innerHTML = data.map(c => `<span class="canton-pill">${escapeHtml(c.nombre)}</span>`).join("");
}

/* ---------- Cargar y renderizar productos ---------- */
async function cargarProductos(){
  const { data, error } = await db
    .from("productos")
    .select("*, categorias(nombre, nombre_en), cantones(nombre)")
    .eq("activo", true)
    .order("created_at", { ascending: false });
  if (error || !data){
    document.getElementById("productGrid").innerHTML = `<div class="empty-state">No se pudieron cargar los productos.</div>`;
    return;
  }
  PRODUCTOS = data;
  renderProductos();
}

function renderProductos(){
  const grid = document.getElementById("productGrid");
  const q = document.getElementById("fBuscar").value.trim().toLowerCase();
  const cat = document.getElementById("fCategoria").value;
  const canton = document.getElementById("fCanton").value;
  const tipo = document.getElementById("fTipo").value;

  let lista = PRODUCTOS.filter(p => {
    if (cat && p.categoria_id !== cat) return false;
    if (canton && p.canton_id !== canton) return false;
    if (tipo === "exportacion" && !p.es_exportacion) return false;
    if (tipo === "artesanal" && !p.es_artesanal) return false;
    if (q && !(`${p.nombre} ${p.descripcion_corta}`.toLowerCase().includes(q))) return false;
    return true;
  });

  if (PRODUCTOS.length === 0){
    grid.innerHTML = `<div class="empty-state">Todavía no hay productos publicados. Vuelve pronto — estamos incorporando nuevos emprendedores cada semana.</div>`;
    return;
  }
  if (lista.length === 0){
    grid.innerHTML = `<div class="empty-state">No encontramos productos con esos filtros. Prueba ajustando la búsqueda.</div>`;
    return;
  }

  grid.innerHTML = lista.map(p => `
    <article class="card-producto reveal">
      <div class="thumb">
        <img src="${escapeHtml(urlImagen(p.imagen_principal_url, "product"))}" alt="${escapeHtml(p.nombre)}" loading="lazy">
        ${p.es_exportacion ? '<span class="badge">Exportación</span>' : (p.es_artesanal ? '<span class="badge">Artesanal</span>' : '')}
      </div>
      <div class="card-body">
        <div class="card-meta"><span>${escapeHtml(lnTexto(p.categorias?.nombre || '', p.categorias?.nombre_en))}</span><span>${escapeHtml(p.cantones?.nombre || '')}</span></div>
        <h3>${escapeHtml(lnTexto(p.nombre, p.nombre_en))}</h3>
        <p>${escapeHtml(cortar(lnTexto(p.descripcion_corta, p.descripcion_corta_en), 100))}</p>
        <div class="tag-row">${(p.etiquetas || []).slice(0,3).map(t => `<span class="tag">${escapeHtml(t)}</span>`).join("")}</div>
        <a href="producto.html?slug=${encodeURIComponent(p.slug)}" class="btn btn-ghost btn-sm">Ver detalles</a>
      </div>
    </article>
  `).join("");
  observeReveals();
  enhanceProductTilt();
}

["fBuscar","fCategoria","fCanton","fTipo"].forEach(id => {
  document.getElementById(id)?.addEventListener("input", renderProductos);
  document.getElementById(id)?.addEventListener("change", renderProductos);
});

// Tracking de búsquedas (debounced) y filtros
let lnBusquedaTimer;
document.getElementById("fBuscar")?.addEventListener("input", (e) => {
  clearTimeout(lnBusquedaTimer);
  const termino = e.target.value.trim();
  if (!termino) return;
  lnBusquedaTimer = setTimeout(() => window.lnTrackBusqueda?.(termino), 800);
});
[["fCategoria","categoria"],["fCanton","canton"],["fTipo","tipo"]].forEach(([id, nombre]) => {
  document.getElementById(id)?.addEventListener("change", (e) => {
    if (e.target.value) window.lnTrackFiltro?.(nombre, e.target.value);
  });
});

/* ---------- Emprendedores ---------- */
async function cargarEmprendedores(){
  const { data, error } = await db
    .from("emprendedores")
    .select("*, cantones(nombre)")
    .eq("activo", true)
    .order("created_at", { ascending: false })
    .limit(6);
  const grid = document.getElementById("empGrid");
  if (error || !data || data.length === 0){
    grid.innerHTML = `<div class="empty-state">Aún no hay emprendedores publicados.</div>`;
    return;
  }
  grid.innerHTML = data.map(e => `
    <article class="card-emp reveal">
      <div class="thumb"><img src="${escapeHtml(urlImagen(e.foto_url, "producer"))}" alt="${escapeHtml(e.nombre)}" loading="lazy"></div>
      <div class="card-body">
        <div class="emprend">${escapeHtml(e.emprendimiento)}</div>
        <h3>${escapeHtml(e.nombre)}</h3>
        <p>${escapeHtml(cortar(e.historia, 110))}</p>
        <div class="card-meta"><span>${escapeHtml(e.cantones?.nombre || '')}</span><span>${e.anios_experiencia ? e.anios_experiencia + ' años' : ''}</span></div>
      </div>
    </article>
  `).join("");
  observeReveals();
}

/* ---------- Noticias ---------- */
const TIPO_LABEL = { feria:"Feria", rueda_negocios:"Rueda de negocios", capacitacion:"Capacitación", convocatoria:"Convocatoria", evento:"Evento" };
async function cargarNoticias(){
  const { data, error } = await db.from("noticias").select("*").eq("activo", true).order("fecha_evento", { ascending: false }).limit(6);
  const grid = document.getElementById("newsGrid");
  if (error || !data || data.length === 0){
    grid.innerHTML = `<div class="empty-state">Aún no hay noticias publicadas.</div>`;
    return;
  }
  grid.innerHTML = data.map(n => `
    <article class="card-news reveal">
      <div class="thumb"><img src="${escapeHtml(urlImagen(n.imagen_url, "news"))}" alt="${escapeHtml(n.titulo)}" loading="lazy"></div>
      <div class="card-body">
        <span class="tipo">${TIPO_LABEL[n.tipo] || 'Noticia'}</span>
        <h3>${escapeHtml(n.titulo)}</h3>
        <p>${escapeHtml(cortar(n.resumen, 90))}</p>
        ${n.fecha_evento ? `<div class="fecha">${new Date(n.fecha_evento).toLocaleDateString('es-EC', { day:'numeric', month:'long', year:'numeric' })}</div>` : ''}
      </div>
    </article>
  `).join("");
  observeReveals();
}

/* ---------- Estadísticas ---------- */
async function cargarStats(){
  const [emp, prod, cant, cat] = await Promise.all([
    db.from("emprendedores").select("id", { count: "exact", head: true }).eq("activo", true),
    db.from("productos").select("id", { count: "exact", head: true }).eq("activo", true),
    db.from("cantones").select("id", { count: "exact", head: true }),
    db.from("categorias").select("id", { count: "exact", head: true }),
  ]);
  const vals = { emprendedores: emp.count || 0, productos: prod.count || 0, cantones: cant.count || 0, categorias: cat.count || 0 };
  document.querySelectorAll("[data-stat]").forEach(el => { el.textContent = vals[el.dataset.stat] ?? "0"; });
  const heroProductos = document.getElementById("heroProductos");
  const heroEmp = document.getElementById("heroEmp");
  if (heroProductos) heroProductos.textContent = vals.productos;
  if (heroEmp) heroEmp.textContent = vals.emprendedores;
}

/* ---------- Init ---------- */
(async function init(){
  lucide.createIcons();
  await Promise.all([cargarCategorias(), cargarCantones(), cargarProductos(), cargarEmprendedores(), cargarNoticias(), cargarStats()]);
})();
